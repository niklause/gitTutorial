package com.example.hello;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost", maxAge = 3600)
@RestController
@RequestMapping("/admin")
public class HelloController {
	@RequestMapping(value = "/check",method = RequestMethod.GET)
	public String displayHello() {
		return "Hello World";
		

	}

}
